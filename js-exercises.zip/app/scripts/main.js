// init handlers
let layoutHandler = null;
let myScript = null;
let formHandler = null;
let randomWord = null;
let filtringData = null;
let pagination = null;
let clockNotifications = null;
let newPaginationLoadMore = null;
let newPaginationFiltering = null;
let loadMore = null;
let themeSeven = null;

const initHandlers = () => {
  layoutHandler = new LayoutHandler();
  // myScript = new MyScript();
  // formHandler = new FormHandler();
  // randomWord = new RandomWord();
  // filtringData = new FiltringData_tema_15();
  // pagination = new Pagination();
  clockNotifications = new ClockNotification();
  themeSeven = new ThemeSeven();
  // newPaginationLoadMore = new NewPaginationLoadMore();
  // newPaginationFiltering = new NewPaginationFiltering();
  loadMore = new LoadMoreNew();
};

// uncomment this to use jQuery
(($) => {
  $(document).ready(() => {
    initHandlers();
  });
})(jQuery);


// init handlers using vanilla
// document.addEventListener('DOMContentLoaded', () => { initHandlers(); });

