var toDo3Handler;

(function ($) {
  "use strict";
  var ToDo3Handler = function () {
    var self = this;
    var savedTaskArr = [],
      listItem = '<li class="list-group-item todo-item">\n  ' +
        '  <div class="custom-control custom-checkbox">\n        ' +
        '<input type="checkbox" class="custom-control-input todo-input" id="task-{{id}}" value="{{input-status}}">\n       ' +
        ' <label class="custom-control-label todo-label" for="task-{{id}}">{{task}}</label>\n    ' +
        '</div>\n  ' +
        '  <span class="badge badge-pill {{badge-color}}">{{status}}</span>' +
        '\n</li>',
      message = '<p>Your task <span class="text-uppercase font-weight-bold">"{{message}}"</span> has been successfully added!</p>';

    this.ready = function () {
      this.handleDOM();
      this.handleEvents();
    };

    this.handleDOM = function () {
      this.todoApp = $('.todo-app');
      this.addTaskBtn = $('.add-task');
      this.AddTaskModal = $('#addItemModal');
      this.message = $('.toast');
      this.modalInput = $('#addItemText');
    };

    this.handleEvents = function () {
      if (this.todoApp.length != 0) {
        // read cookie
        var saveTask = $.cookie('toDoApp');
        this.getCookie(saveTask, savedTaskArr);

        // add new task function
        this.addTaskBtn.on('click tap', function (e) {
          e.preventDefault();
          var task = self.modalInput.val(),
            newId = savedTaskArr.length + 1,
            taskStatus = 'In progress',
            badgeColor = 'badge-danger',
            inputChecked = 'unchecked',

            newListItem = listItem
              .replace("{{task}}", task)
              .replace("{{id}}", newId)
              .replace("{{id}}", newId)
              .replace("{{status}}", taskStatus)
              .replace("{{badge-color}}", badgeColor)
              .replace("{{input-status}}", inputChecked),
            newMessage = message.replace("{{message}}", task);

          $('.todo-list').append($(newListItem));

          // add message in toast
          self.message.find('.toast-body p').remove();
          self.message.find('.toast-body').append($(newMessage));

          // empty input, close modal, show toast
          self.modalInput.val('');
          self.AddTaskModal.modal('toggle');
          self.message.toast('show');

          // populate array
          savedTaskArr.push({
            task: task,
            taskId: newId,
            status: taskStatus,
            badgeColor: badgeColor,
            inputChecked: inputChecked
          });

          // save array in cookie
          self.setCookie(savedTaskArr);
        });

        $('body').on('change', '.todo-input', function () {
          self.updateTaskList($(this));
        });

        $(window).on('load', function () {
          self.drawTaskList();
          self.inputState();
        });
      }
    };

    // set cookie
    this.setCookie = function (arr) {
      var json_str = JSON.stringify(arr);
      $.cookie('toDoApp', json_str, {expires: 7, path: '/'});
    };

    // get cookie
    this.getCookie = function (cookie, arr) {
      if (cookie != undefined) {
        var savedTaskArr = JSON.parse(cookie);
        for (var i = 0; i < savedTaskArr.length; i++) {
          arr.push(savedTaskArr[i]);
        }
        return arr;
      }
    };

    // draw task list from cookie
    this.drawTaskList = function () {
      $.each(savedTaskArr, function (k, v) {
        var label = v.task,
          id = v.taskId,
          status = v.status,
          badgeColor = v.badgeColor,
          inputChecked = v.inputChecked,

          newItem = listItem
            .replace("{{task}}", label)
            .replace("{{id}}", id)
            .replace("{{id}}", id)
            .replace("{{status}}", status)
            .replace("{{badge-color}}", badgeColor)
            .replace("{{input-status}}", inputChecked);

        $('.todo-list').append($(newItem));
      });
    };

    // check input state
    this.inputState = function () {
      $('.todo-input').each(function () {
        if ($(this).val() === "checked") {
          $(this).prop('checked', true).attr('checked', 'checked');
        } else {
          $(this).prop('checked', false).attr('checked', 'unchecked');
        }
      });
    };

    // update tasks list
    this.updateTaskList = function (item) {
      var input = item,
        inputId = item.prop('id'),
        tId = parseInt(inputId.split('-')[1]) - 1,
        status = input.parents('.custom-checkbox').siblings('.badge');

      // check if input type="checkbox" is checked and update array
      if (input.prop('checked') === true) {
        status.removeClass('badge-danger');
        status.addClass('badge-success').text('Done');
        savedTaskArr[tId].status = "Done";
        savedTaskArr[tId].badgeColor = "badge-success";
        savedTaskArr[tId].inputChecked = 'checked';
      } else {
        status.removeClass('badge-success');
        status.addClass('badge-danger').text('In progress');
        savedTaskArr[tId].status = "In progress";
        savedTaskArr[tId].badgeColor = "badge-danger";
        savedTaskArr[tId].inputChecked = 'unchecked';
      }

      // save updated array in cookie
      self.setCookie(savedTaskArr);
    };
  };

  toDo3Handler = new ToDo3Handler();

  $(document).ready(function () {

    toDo3Handler.ready();
  });
})(jQuery);
