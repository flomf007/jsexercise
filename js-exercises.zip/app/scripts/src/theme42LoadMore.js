// de facut un fetch sa iau datele
// cu 2 parametri skip/limit
// pt desenarea paginarii ma folosesc de parametru total
// de avut urmatoarele variabiel, currentPage, perPage, totalPages = (MathCeil(totalPages / perPage))
// total pages = for si desenez butoanele
// load more functioneaza pe toate
// o pagina cu filtrarea de select
// all items merge pe toate paginile de filtare

class NewPaginationLoadMore {

  constructor() {
    if (!$('.load-more-items').length) {
      return
    }
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
    this.elToLoad = 4;
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.onLoadFetchdataArr = [];
    this.categoryFetchDataArr = [];
    this.buttonCategory = [];
    this.itemsByCategory = [];
    this.itemsByCategoryLimit = [];
    this.pageContent = $('.listing-body ul');
    this.pageContentLi = $('.listing-body ul li');
    this.setFirstLoad = 1;
    this.loadMore = 4;
    this.limit = 100;
    this.categoryButtonsContainer = $('.category-buttons');
  }

  loaderDisplay(){
    let self = this;
    this.pageContent.addClass("show-loader");
    setTimeout(function () {
      self.pageContent.removeClass("show-loader");
    }, 500);
  }

  //DONE
  appendData(categoryItem) {
      if(categoryItem === undefined) {
      this.onLoadFetchdataArr.forEach(item => {
        this.drawtemplate(item)
      })
    } else {
        this.itemsByCategory.forEach(item => {
        this.drawtemplate(item)
      });
    }
  }

  //DONE
  drawtemplate(categoryItem) {
    this.pageContent.append(`<li >
                <h3>
                <span>${categoryItem.id}. </span>
                  ${categoryItem.title}
                  </h3>
                <div class="container__post--content">
                   <h6>Get your at a discount price of ${categoryItem.discountPercentage} </h6>
                        <div class="image-area">
                             <img src="${categoryItem.thumbnail}" alt="">
                        </div>
                           <p> </p>
                        <ul>
                          <li>Brand: ${categoryItem.brand}</li>
                          <li>Category: ${categoryItem.category}</li>
                           <li>Description: ${categoryItem.description}</li>
                              <li>Price: ${categoryItem.price}</li>
                        </ul>
                  </div>
        </li>`)
  }

  //DONE
  fetchCategoriesData(){
    fetch(`https://dummyjson.com/products/categories`)
      // fetch(`https://dummyjson.com/products`)
      .then((res) => res.json())
      .then((data) => {
        this.buttonCategory = data;
      });
  }

  //DONE
  fetchAllProductsData() {
    // fetch(`https://dummyjson.com`)
    fetch(`https://dummyjson.com/products`)
      .then((res) => res.json())
      .then((allData) => {
        this.categoryFetchDataArr = allData.products;
        // this.totalPosts = allData.total;
        this.totalPosts = allData.total;

        return this.categoryFetchDataArr;
      });
  }

  fetchData(skipNumberOfElements) { //data fetched when page loads and on when clicked on Load more
    fetch(`https://dummyjson.com/products?limit=${this.elToLoad}&skip=${skipNumberOfElements}`)
      // fetch(`https://dummyjson.com/products`)
      .then((res) => res.json())
      .then((data) => {
        this.onLoadFetchdataArr = data.products;

      });
  };

  // detectAction(numberProducts, buttonCategory) {
  detectAction(buttonAction) {
    let self = this;
    //Reset DONE  -  Load more DONE
    if (buttonAction === 'reset') {
        $('.listing-body ul li').remove();
        $('.pagination-number').remove();
        $('.category-pagination-number').remove();
        $('.load-more-button').show();
        self.loaderDisplay();
        self.calculatePosts(self.elToLoad, 1 , 4);
        self.setFirstLoad = 1; //reset value for first load value back to 1
        self.loadMore = 4; //reset value for load more value back to 1
    } else if (buttonAction === 'load-more') {
        self.calculatePosts(self.elToLoad, self.setFirstLoad + 1, self.loadMore + 4);
        self.loaderDisplay();
        $('.pagination-number').hide();
      // self.calculatePosts(self.elToLoad, self.setFirstLoad + 1, self.loadMore + 4);
      // self.calculatePosts(self.elToLoad, self.setFirstLoad + 1, self.loadMore + 4);
    } else if(buttonAction === 'all-items') {
        $('.listing-body ul li').remove();
        self.calculatePosts(self.elToLoad, 1, 4);
        self.loaderDisplay();
        self.drawPagination();
        $('.load-more-button').hide();
        let paginationElement = $('.pagination-number');
        paginationElement.removeClass('active btn-primary').addClass('btn-secondary');
        $("body").find(paginationElement).eq(0).removeClass("btn-secondary").addClass('btn-primary active');
    } else {
        $('.listing-body ul li').remove();
        $('.pagination-number').remove();
        self.loaderDisplay();
        self.drawCategoryPagination(buttonAction);
    }
  }

  calculatePosts(maximumElements, elementValueToCalc, addedNewElements, buttonAction) {
    let self = this;
    this.setFirstLoad = elementValueToCalc;
    this.loadMore = addedNewElements;

    let elementsCalc = (elementValueToCalc - 1) * 4;

    // de detectat daca primesc o categorie si fac fetch-ul in functie de astas
    // creez o variabila cu link-ul de fetch al tuturor produselor
    //la click pe categorie, actualizez variabila cu link-ul de categorie si ce alte valori mai am nevoie
    //ex variabila this.endpoint = https://dummyjson.com/products
    //ex variabila dupa click pe categorie this.endPoint =https://dummyjson.com/products/category/CATEGORIE

    this.fetchData(elementsCalc);

    this.loaderDisplay();

    if(this.loadMore === this.totalPosts){
      $('.load-more-button').hide();
    }

    setTimeout(function () {
      self.appendData();
    }, 200);


  }

  fetchItemsBycategory(itemCategory, numberOfItemsToLoad, itemsToSkip) {
   fetch(`https://dummyjson.com/products/category/${itemCategory}?limit=${numberOfItemsToLoad}&skip=${itemsToSkip}`)
   //  fetch(`https://dummyjson.com/products/category/${category}`)
      .then((res) => res.json())
      .then((data) => {
        this.itemsByCategory = data.products;
      });
    return this.itemsByCategory;
  }

  calculateCategoryPosts(numberOfItemsToLoad, pageNumber, totalNrOfElementsInItem, itemCategory, activePageIndex){
    let self = this;

    let calcPageElements = (pageNumber - 1) * this.elToLoad;
    let currRange = pageNumber * this.elToLoad;
    this.setFirstLoad = pageNumber;
    this.loadMore = numberOfItemsToLoad;

    // this.fetchItemsBycategoryLimit(itemCategory, numberOfItemsToLoad, calcPageElements);
    // this.fetchItemsBycategory(itemCategory, currRange, calcPageElements);

    this.loaderDisplay();
    // this.fetchItemsBycategory(itemCategory, calcPageElements, 0 );
    // this.fetchItemsBycategory(itemCategory, itemsNumberToLoad, elementsCalcToLoad);
    // this.fetchItemsBycategory(itemCategory, itemsNumberToLoad, pageValue, elementsCalcToLoad );

    if(this.loadMore === this.totalPosts){
      $('.load-more-button').remove();
    }

    setTimeout(function () {
      self.appendData(itemCategory);
    }, 500);
  }

  //DONE
  drawFilterButtonsByCategory() {
    let self = this;
    self.buttonCategory.forEach(item => {
      self.categoryButtonsContainer.append(`
                                   <button class="filter-button btn btn-secondary btn-sm ${item}" data-id="${item}"> ${item}</button>
                           `
      );
    });

  }

  drawCategoryPagination(category){
    let self = this;
    setTimeout(function () {
      $('.category-pagination-number').remove();
      let pageCount = Math.ceil(self.itemsByCategory.length / self.elToLoad);

      for (let i = 0; i < pageCount; i++) {
        $('#pagination-numbers').append(`<button data-category='${category}' class="category-pagination-number" page-index="${i + 1}" value="${i + 1}">${i + 1}</button>`);
      }

    }, 300);
  }

  //DONE
  drawPagination() {
    if(!$('.pagination-number').length){
      let pageCount = Math.ceil(this.categoryFetchDataArr.length / this.elToLoad);
      for (let i = 0; i < pageCount; i++) {
        $('#pagination-numbers').append(`<button class="pagination-number btn btn-secondary btn-sm" page-index="${i + 1}" value="${i + 1}">${i + 1}</button>`);
      }
    }
  }


  handleActivePageNumber(thisCurrentElIndex) {

    let paginationElement = $('.pagination-number');
    paginationElement.removeClass('active btn-primary').addClass('btn-secondary');

    //The eq() method returns an element with a specific index number of the selected elements.
    // The index numbers start at 0, so the first element will have the index number 0 (not 1).
    $("body").find(paginationElement).eq(thisCurrentElIndex).removeClass("btn-secondary").addClass("active btn-primary");

  }

  /**
   * Listen for events
   */

  handleEvents() {
    let self = this;

    this.fetchData(0);

    this.fetchCategoriesData();  //Categories data fetched
    this.fetchAllProductsData(); //All data fetched

    setTimeout(function () {
      self.appendData();
      // self.fetchCategoriesData();
      self.drawFilterButtonsByCategory();
    }, 300);

    //detect what action button was clicked
    $("body").on('click tap', `.buttons-area button`, function (e) {
      e.preventDefault();
      let getAction = $(this).attr('data-id');
      $('button').removeClass('active btn-primary').addClass('btn-secondary');
      self.fetchItemsBycategory(getAction, self.limit, 0 );
      $(`button.${getAction}`).removeClass('btn-secondary').addClass('active btn-primary');

      setTimeout(function () {

        self.calculateCategoryPosts(self.itemsByCategory.length, 1, 4, getAction);
        self.detectAction(getAction);
        console.log(self.itemsByCategory.length);
      }, 200);



    });

    //Use navigation to go through items
    $("body").on('click tap', `.pagination-number`, function (e) {
      e.preventDefault();
      let currentIndex = $(this).index();
      let currentValue = Number($(this).attr('value'));
      $('.listing-body ul li').remove();
      self.handleActivePageNumber(currentIndex);
      self.calculatePosts(self.elToLoad, currentValue);
    });

    $("body").on('click tap', `.category-pagination-number`, function (e) {
      e.preventDefault();
      let currentIndex = $(this).index();
      let currentElValue = Number($(this).attr('value'));
      let currentCategory = $(this).attr('data-category');
      $('.listing-body ul li').remove();

      self.handleActivePageNumber(currentIndex);
      self.calculateCategoryPosts(self.elToLoad, currentElValue, self.loadMore, currentCategory, currentIndex);
      self.drawCategoryPagination(currentCategory, currentIndex, currentElValue);
      // self.drawFilterButtonsByCategory(currentIndex, currentElValue);

    });
  }
}



