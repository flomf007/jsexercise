class RandomWord {

  constructor() {
    if (!$('.random-word').length) {
      return
    }
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.lettersListing = $(`.letters-listing ul`);
    this.lettersListingCorrectUsed = $(`.letters-used ul.correct-letters`);
    this.lettersListingWrongUsed = $(`.letters-used ul.wrong-letters`);
    this.randomWordSection = $('.display-word-section ul');

    // word listing
    this.words = [
      'Special',
      'Dynamic',
      'Simple',
      'Great',
      'Better',
      'Stronger',
      'Stylish',
      'Flawless',
      'Envied',
      'Strong',
      'Sucessful',
      'Grow',
      'Innovate',
      'Global',
      'Knowledgable',
      'Unique',
      'Trusted',
      'Efficient',
      'Reliable',
      'Stable',
      'Secure',
      'Sofisticated',
      'Evolving',
      'Colorful',
      'Admirable',
      'Sexy',
      'Trending',
      'Shine',
      'Noted',
      'Famous',
      'Inspiring',
      'Important',
      'Bigger',
      'Stylish',
      'Expand',
      'Proud',
      'Awesome',
      'Solid'];

    //generate a word
    this.selectedWord = function () {
      //random nr between 1 and number of words in the this.words variable
      //The number reprezents the word that is in that nr position
      this.randomNumber = Math.trunc(Math.random() * this.words.length);
      let word = this.words[this.randomNumber]; //get the word
      return word; //return the word
    };

    //generam dinamic literele folosind charcode-urile de la 65 pana se ajunge la un nr de 26 de caractere
    this.alpha = Array.from(Array(26)).map((e, i) => i + 65);
    //mapam fiecare litera creata dinamic si le punem intr-un string
    this.alphabet = this.alpha.map((x) => String.fromCharCode(x));

    this.maxChances = 3;
    this.chancesHtmlSpanEl = $('.chances-left span');
    this.playAgainBtn = $('.play-again-button button');
    this.countCorrectLetters = [];

  }

  /**
   * Listen for events
   */
  handleEvents() {
    let self = this;
    let chosenWordOnLoad = self.selectedWord().toUpperCase(); //save selected word on load
    let splittWord = chosenWordOnLoad.split("");
    let wordLenght = chosenWordOnLoad.length;
    let underlineInsert = `<li class="letter hidden-letter">_</li>`;
    let repeatUnderlineInsert = underlineInsert.repeat(wordLenght);

    console.log(splittWord);

    self.randomWordSection.append(repeatUnderlineInsert);

    //create alphabet listing
    for (let i = 0; i < self.alphabet.length; i++) {
      self.lettersListing.append(`<li data-key="${self.alphabet[i]}"><span>${self.alphabet[i]}</span></li>`)
    }

    //display max number of chances
    self.chancesHtmlSpanEl.html(`${self.maxChances}`);

    let guessingGame = function(keyTarget, chancesLeftCounter, whiteSpace, letterUsed) {
      let key = keyTarget;
      let letterUsedEl = letterUsed;
      let whiteSpaceEl = whiteSpace;
      let chancesLeft = chancesLeftCounter;


      if(self.lettersListing.hasClass('active')){ //check if letter listing table is active
       if(chosenWordOnLoad.indexOf(letterUsedEl) !== -1 ){

          for (let i = 0; i <= whiteSpaceEl.length; i++){
            if(chosenWordOnLoad[i] === key) {
              $('.letter')[i].innerText = key;
              self.countCorrectLetters += key; //save all correct letters in the array
              self.lettersListingCorrectUsed.append(`<li>${letterUsedEl}</li>`);
              setTimeout(function () {
                //check if correct letters array lenght is equal tu the generated word lenght
                if(self.countCorrectLetters.length === wordLenght){
                  self.lettersListing.removeClass('active').addClass('disabled');
                  self.lettersListingCorrectUsed.append(`<span>You've won! The word was ${chosenWordOnLoad}</span>`)
                }
              }, 100)
            }
          }
        } else {
          self.lettersListingWrongUsed.append(`<li>${letterUsedEl}</li>`);
          setTimeout(function () {
              self.chancesHtmlSpanEl.html(`${chancesLeft}`);
            if(chancesLeft === 0 ) {
              self.lettersListing.removeClass('active').addClass('disabled');
              self.chancesHtmlSpanEl.html(`<span>You have used all your chances. You LOST!!!Muahaha</span>`);
            }
          }, 100)
        }
      }
    };


    //on letter click reduce the number of chances and display used letters in listing
    $("body").on('click tap', `.active li`, function (e) {
      let keyTarget = e.target.innerText;
      let whiteSpace = $('.letter');
      let letterUsed = $(this).text().trim();
      let chancesLeftCounter = Number(self.chancesHtmlSpanEl.text()) - 1;
      $(this).addClass('disabled');
      guessingGame(keyTarget, chancesLeftCounter, whiteSpace, letterUsed);
    });

    $(document).on('keyup', function(letterPress) {

      let keyTarget = letterPress.key.toUpperCase();
      let whiteSpace = $('.letter');
      let letterUsed = keyTarget;
      let chancesLeftCounter = Number(self.chancesHtmlSpanEl.text()) - 1;

      self.lettersListing.find(`[data-key='${keyTarget}']`).addClass('disabled');

      guessingGame(keyTarget, chancesLeftCounter, whiteSpace, letterUsed);
    });


    self.playAgainBtn.on('click tap', function () {
      location.reload();
    });
  }
}

