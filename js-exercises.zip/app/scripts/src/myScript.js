class MyScript {


  constructor() {
    if (!$('.page-users').length) {
      return
    }

    this.handleEvents();
    this.init();
    this.handleDOM();
    // this.fetchListData();
  }


  /**
   * Declare global variables
   */
  init() {
    this.arraydata = [];
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.toDoList = $('.panel-to-do .panel-body ul');
    this.doneList = $('.panel-done-list .panel-body ul');
    this.fetchAddress = "https://jsonplaceholder.typicode.com/todos";
    this.cloneArr = [];
    this.abc = 'asd';
  }

  fetchListData() {
    fetch("https://jsonplaceholder.typicode.com/todos")
      .then((res) => res.json())
      .then((data) => {
        data.forEach((item) => {
          if (this.cloneArr.length < 5) {
            this.cloneArr.push(item);
          }
          this.setItemState();
        });
      });
  };

  segultItemState = function(i, e) {
    $.each(this.cloneArr, function (i, e) {
      e.completed = false;
    });
  };

  /**
   * Listen for events
   */
  handleEvents() {

    let self = this;

    // let updateCookie = function(i, e) {
    //   $.each(cloneArr, function (i, e) {
    //     e.completed = false;
    //   });
    // };
    //
    //   $.get("https://jsonplaceholder.typicode.com/todos", function( data ) {
    //     // self.arraydata = data.slice(0 , 5);
    //     cloneArr = data.slice(0 , 5);
    //     updateCookie();
    //   });


    this.fetchListData();

    let drawList = function() {

      for (let i = 0; i < self.cloneArr.length; i++) {

          self.toDoList.append (`
                    <li class="to-do-item">
                      <div class="checkbox-group ">
                            <input class="input" type="checkbox" id="${self.cloneArr[i].id}" name="${self.cloneArr[i].id}">
                            <label class="label" for="${self.cloneArr[i].id}"> ${self.cloneArr[i].title}</label>
                      </div>
                    </li>`);
      }
    };

    setTimeout(function () {

      let savedCookie = $.cookie('saved-data');
      if (savedCookie !== undefined) {
        self.cloneArr = JSON.parse(savedCookie);
        console.log(self.cloneArr);
        for (let i = 0; i < self.cloneArr.length; i++) {
          if (self.cloneArr[i].completed === true) {
            self.doneList.append (`
                    <li class="done-item">
                      <div class="checkbox-group ">
                            <input class="input" type="checkbox" id="${self.cloneArr[i].id}" name="${self.cloneArr[i].id}" checked="checked">
                            <label class="label" for="${self.cloneArr[i].id}"> ${self.cloneArr[i].title}</label>
                      </div>
                    </li>`);

          } else {
            setTimeout(function () {
              self.toDoList.append (`
                    <li class="to-do-item">
                      <div class="checkbox-group ">
                            <input class="input" type="checkbox" id="${self.cloneArr[i].id}" name="${self.cloneArr[i].id}">
                            <label class="label" for="${self.cloneArr[i].id}"> ${self.cloneArr[i].title}</label>
                      </div>
                    </li>`);
            }, 400)
          }
        }
      } else {
        drawList();
      }
    }, 500);

    $("body").on("click", 'input', function() {
       if($(this).prop('checked') === true) {

        let inputId = $(this).attr('id');

        $.each(self.cloneArr, function (index, item) {
          if (Number(inputId) === item.id) {
            item.completed = true;
          }
        });

        $(this).parents('li').removeClass('to-do-item').addClass('done-item');
        self.doneList.append($(this).parents('li'));

      } else  {

         let inputId = $(this).attr('id');
         $.each(self.cloneArr, function (index, item) {
           if(Number(inputId) === item.id) {
             item.completed = false;
           }
         });

        $(this).parents('li').addClass('to-do-item').removeClass('done-item');
        self.toDoList.append($(this).parents('li'));
      }
    });

    $('.save').on('click', function() {
      $.cookie(`saved-data`, JSON.stringify(self.cloneArr));
      window.location.reload();
    });
  }
}



