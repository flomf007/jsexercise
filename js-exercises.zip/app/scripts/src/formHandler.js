class FormHandler {


  constructor() {
    if (!$('.page-form').length) {
      return
    }
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {

  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.pageForm = $('.page-form');
    this.form = $('#trainingForm');
    this.submitBtn =  $('.form-submit-button');
    this.succesDiv = $(".succes-messages");
    this.sexField = $('#sex');
    this.nameField = $('#name');
    this.lastNameField = $('#lastName');
    this.cnpField = $('#cnp');
    this.serieCiField = $('#serieCi');
    this.nrCiField = $('#nrCi');
    this.phoneField = $('#phone');
    this.emailField = $('#email');
    this.subiectField = $('#subiect');
    this.messageField = $('#message');
    this.gdprField = $('#gdpr');
    this.modalBg = $('.modal-background');
    this.formModal = $('.form-modal');
    this.formModalContent = $('.form-modal .modal-body');
    this.closeModal = $('.close');
    this.resetForm = function() {
      this.sexField.val('');
      this.nameField.val('');
      this.lastNameField.val('');
      this.cnpField.val('');
      this.serieCiField.val('');
      this.nrCiField.val('');
      this.phoneField.val('');
      this.emailField.val('');
      this.subiectField.val('');
      this.messageField.val('');
      this.gdprField.prop('checked', false);
    };
  }

  /**
   * Listen for events
   */
  handleEvents() {
    let self = this;

    $.validator.addMethod("digitsonly", function (value, element) {
      return this.optional(element) || /^[0-9]+$/g.test(value);
    }, "");

    $.validator.addMethod("onlyLetters", function (value, element) { //with spaces in between
      return this.optional(element) || /^[a-zA-Z\s]+$/g.test(value);
    }, "");

    $.validator.addMethod("nameValidator", function (value, element) { //without spaces in between
      return this.optional(element) || /^[a-zA-Z-\S]+$/g.test(value);
    }, "");

    $.validator.addMethod("phoneRO", function (phone_number, element) {
      phone_number = phone_number.replace(/\(|\)|\s+|-/g, "");
      return this.optional(element) || phone_number.length > 9 &&
        phone_number.match(/^(?:(?:07\d{2}\S?\d{3}\S?\d{3}|(21|31)\d{1}\S?\d{3}\S?\d{3}|((2|3)[3-7]\d{1})\S?\d{3}\S?\d{3}|(8|9)0\d{1}\S?\d{3}\S?\d{3}))$/);
    }, "");

    $.validator.addMethod("email", function(value, element) {
      return this.optional( element ) || /^([0-9a-zA-Z]+[-._+&amp;])*[0-9a-zA-Z]+@([-0-9a-zA-Z]+[.])+[a-zA-Z]{2,6}$/.test( value );
    }, 'Introdu o adresa de email valida.');

    $.validator.addMethod("roCNP", function(value, element) {
      return this.optional( element ) || /^[1-9]\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])(0[1-9]|[1-4]\d|5[0-2]|99)(00[1-9]|0[1-9]\d|[1-9]\d\d)\d$/.test( value );
    }, '');

    this.form.validate({
      rules: {
        sex: {
          required: true,
        },
        name: {
          required: true,
          digitsonly: false,
          nameValidator: true,
          minlength: 2,
          maxlength: 10,
        },
        lastName: {
          required: true,
          digitsonly: false,
          onlyLetters: true,
          minlength: 2,
          maxlength: 10,
        },
        cnp: {
          required: true,
          digitsonly: true,
          roCNP: true,
          minlength: 13,
          maxlength: 13,
        },
        serieCi: {
          required: true,
          nameValidator: true,
          minlength: 2,
          maxlength: 2,
        },
        nrCi: {
          required: true,
          digitsonly: true,
          number: true,
          minlength: 6,
          maxlength: 6,
        },
        phone: {
          required: true,
          digitsonly: true,
          phoneRO: true,
          minlength: 10,
          maxlength: 10,
        },
        email: {
          required: true,
          email: true,
        },
        subiect: {
          required: true,
        },
        message: {
          required: true,
          minlength: 150,
        },
        gdpr: {
          required: true
        }
      },
      messages: {
        sex: {
          required: 'Acest camp este obligatoriu',
        },
        name: {
          required: 'Acest camp este obligatoriu',
          digitsonly: 'Sunt permise doar litere',
          nameValidator: 'Sunt permise doar litere si fara spatii.',
          minlength: 'Introdu minim 2 caractere',
          maxlength: 'Maxim 10 caractere sunt permise',
        },
        lastName: {
          required: 'Acest camp este obligatoriu',
          digitsonly: 'Sunt permise doar litere',
          nameValidator: 'Sunt permise doar litere si fara spatii.',
          minlength: 'Introdu minim 2 caractere',
          maxlength: 'Maxim 20 caractere sunt permise',

        },
        cnp: {
          required: 'Acest camp este obligatoriu',
          digitsonly: 'Nu sunt permise litere. Introdu numai cifre',
          minlength: 'Minim 13 caractere sunt permise',
          maxlength: 'Minim 13 caractere sunt permise',
          roCNP: 'Introdu un CNP valid.'
        },
        serieCi: {
          required: 'Acest camp este obligatoriu',
          nameValidator: 'Sunt permise doar litere si fara spatii goale',
          minlength: 'Minim 2 caractere sunt permise',
          maxlength: 'Minim 2 caractere sunt permise',
        },
        nrCi: {
          required: 'Acest camp este obligatoriu',
          number: 'Introdu doar cifre',
          digitsonly: 'Introdu doar cifre',
          onlyLetters: 'Nu sunt permise doar litere',
          minlength: 'Minim 6 caractere sunt permise',
          maxlength: 'Minim 6 caractere sunt permise',
        },
        phone: {
          required: 'Acest camp este obligatoriu',
          digitsonly: 'Introdu doar cifre',
          phoneRO: "Introdu un numar valid",
          minlength: 'Minim 10 caractere sunt permise',
          maxlength: 'Minim 10 caractere sunt permise',
        },
        email: {
          required: 'Acest camp este obligatoriu',
          email: 'Introdu o adresa de email valida'
        },
        subiect: {
          required: 'Acest camp este obligatoriu',
        },
        message: {
          required: 'Acest camp este obligatoriu',
          minlength: 'Introdu minim 150 de caractere.'
        },
        gdpr: {
          required: `Acest camp este obligatoriu. Nu uita sa bifezi daca esti de acord.`
        }
      },

      submitHandler: function (form, event) {
        event.preventDefault();
        jQuery.ajax({
          success: function (response) {
            $('.error').remove();
            if(response.length) {
              self.succesDiv.html('<p>Formularul a fost trimis cu succes.</p>');
              self.modalBg.addClass('show');
              self.formModal.addClass('show');

              self.formModalContent.append(`
              <ul>
                <li>
                  <p>Nume:</p>
                  <span>${self.nameField.val()}</span>
                </li>
                <li>
                  <p>Prenume:</p>
                  <span>${self.lastNameField.val()}</span>
                </li>
                <li>
                  <p>Email:</p>
                  <span>${self.emailField.val()}</span>
                </li>
                <li>
                  <p>Nr. Serie CI:</p>
                  <span>${self.nrCiField.val()}</span>
                </li>
              </ul>`)
            }
          }
        });
      }
    });

    self.closeModal.on('click', function () {
      self.resetForm();
      self.modalBg.removeClass('show');
      self.formModal.removeClass('show');
      self.succesDiv.html('');
      self.formModalContent.html('');
    });
  }
}
