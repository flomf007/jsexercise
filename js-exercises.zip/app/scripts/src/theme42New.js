class LoadMoreNew {

  constructor() {
    if (!$('.load-more-items').length) {
      return
    }
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
    this.elToLoad = 4;
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.onLoadFetchdataArr = [];
    this.categoryFetchDataArr = [];
    this.itemsByCategory = [];
    this.totalProducts = [];
    this.url = '';
    this.pageContent = $('.listing-body ul');
    this.pageContentLi = $('.listing-body ul li');
    this.perPage = 4;
    this.currentPage = 1;
    this.categoryButtonsContainer = $('.category-buttons');
    this.select = $('#select');
    this.categorySelected = '';
    this.categoryList = '';
    this.navigateButton = $('.pagination-button');
  }

  //DONE
  drawProductTemplate(categoryItem) {
    this.pageContent.append(`<li >
                <h3>
                <span>${categoryItem.id}. </span>
                  ${categoryItem.title}
                  </h3>
                <div class="container__post--content">
                   <h6>Get your at a discount price of ${categoryItem.discountPercentage} </h6>
                        <div class="image-area">
                             <img src="${categoryItem.thumbnail}" alt="">
                        </div>
                           <p> </p>
                        <ul>
                          <li>Brand: ${categoryItem.brand}</li>
                          <li>Category: ${categoryItem.category}</li>
                           <li>Description: ${categoryItem.description}</li>
                              <li>Price: ${categoryItem.price}</li>
                        </ul>
                  </div>
        </li>`)
  }

  //DONE
  fetchCategoriesData(){
    fetch(`https://dummyjson.com/products/categories`)
      .then((res) => res.json())
      .then((data) => {
        data.forEach(item => {
          this.categoryButtonsContainer.append(`
                                   <button class="filter-button btn btn-secondary btn-sm ${item}" data-id="${item}"> ${item}</button>
                           `
          );
          this.select.append(`<option value="${item}" class="option">${item}</option>`);
        });
      });
  }

  fetchData(url) { //data fetched when page loads and on when clicked on Load more
    let self = this;
    self.pageContent.addClass("show-loader");
    fetch(url)
      .then((res) => res.json())
      .then((data) => {
        this.onLoadFetchdataArr = data.products;
        this.totalProducts = data.total;
        this.onLoadFetchdataArr.forEach(item => {
          this.drawProductTemplate(item)
        });
      }).finally( () => {
        self.pageContent.removeClass("show-loader");
        }
    )
  };

  pageNavigate(buttonValue, setNewActiveIndex, getNextValue,  selectedCategory) {
    let self = this;
    if(buttonValue !== 'load-more') {
      self.pageContent.html('');
    }
    if (selectedCategory === ''|| self.categorySelected === 'all') {
      self.url = `https://dummyjson.com/products?limit=${self.perPage}&skip=${getNextValue}`;
    } else {
      self.url = `https://dummyjson.com/products/category/${selectedCategory}?limit=${self.perPage}&skip=${getNextValue}`;
    }
    this.fetchData(self.url);
    setTimeout(function () {
      self.drawPagination(getNextValue, setNewActiveIndex);
    }, 400);
  }


  disableFirstPrevButtons(){
    $('.prev-button').addClass('disabled').attr("disabled", true);
    $('.first-page').addClass('disabled').attr("disabled", true);
  }
  enableFirstPrevButtons(){
    $('.prev-button').removeClass('disabled').attr("disabled", false);
    $('.first-page').removeClass('disabled').attr("disabled", false);
  }
  disableLastNextButtons(){
    $('.next-button').addClass('disabled').attr("disabled", true);
    $('.last-page').addClass('disabled').attr("disabled", true);
  }
  enableLastNextButtons(){
    $('.next-button').removeClass('disabled').attr("disabled", false);
    $('.last-page').removeClass('disabled').attr("disabled", false);
  }

  //DONE
  drawPagination(pageIndex, setNewActiveIndex) {
    let self = this;
    let pageCount = Math.ceil(self.totalProducts / self.perPage);
    let pageNumber = setNewActiveIndex + 1;
    $('#pagination-numbers').html('');

    for (let i = 0; i < pageCount; i++) {
      $('#pagination-numbers').append(`<button class="pagination-number btn btn-secondary btn-sm" 
          page-index="${i + 1}" value="${i + 1}">${i + 1}</button>`);
    }

    if (pageNumber === pageCount) {
      self.enableFirstPrevButtons();
      self.disableLastNextButtons();
    } else if (pageNumber === self.currentPage){
      self.disableFirstPrevButtons();
      self.enableLastNextButtons();
    } else if(pageNumber > self.currentPage || pageNumber < pageCount) {
      self.enableFirstPrevButtons();
      self.enableLastNextButtons()
    }

    self.handleActivePageNumber(setNewActiveIndex, pageCount);
  }

  handleActivePageNumber(currentElIndex, pageCount) {
    let paginationElement = $('.pagination-number');
    paginationElement.removeClass('active');

    //The eq() method returns an element with a specific index number of the selected elements.
    // The index numbers start at 0, so the first element will have the index number 0 (not 1).
    $("body").find(paginationElement).eq(currentElIndex).addClass("active");
    this.handlePageNavigation(currentElIndex, pageCount);
  }

  handlePageNavigation(currentElIndex, pageCount) {
    if(currentElIndex >= 4) {
      $('.pagination-number').hide();
      $('.pagination-number').slice(currentElIndex - 2, currentElIndex + 3).show();
    } else if(currentElIndex > 0) {
      $('.pagination-number').hide();
      $('.pagination-number').slice(currentElIndex - 1, currentElIndex + 4).show();
    } else if (currentElIndex === 1){
      $('.pagination-number').hide();
      $('.pagination-number').slice(currentElIndex, currentElIndex + 5).show();
    } else if(currentElIndex === 0) {
      $('.pagination-number').hide();
      $('.pagination-number').slice(0, currentElIndex + 5).show();
    } else if (pageCount) {
      $('.pagination-number').hide();
      $('.pagination-number').slice(pageCount - 4, pageCount ).show();
      $("body").find($('.pagination-number')).eq(pageCount -1).addClass("active");
      }
  }


  /**
   * Listen for events
   */

  handleEvents() {
    let self = this;
    this.fetchCategoriesData();  //Categories data fetched
    self.pageNavigate('', 0, 0, self.categorySelected);

    //DONE
    $('.load-more').on('click', function (e) {
      e.preventDefault();
      let buttonValue = $(this).val();
      self.currentPage = self.currentPage + 1; //Need to set increased value for Current Page on each click on Load More
      let nextElements = (self.currentPage - 1) * 4;

      self.pageNavigate(buttonValue, '', nextElements, self.categorySelected);

      setTimeout(function () {
        // Check if the array has less than 4 items in it
        // If yes, it means that it reached the end and has no more items to fetch
        if (self.onLoadFetchdataArr.length < 4) {
          $('.load-more').hide();
        } else {
          self.onLoadFetchdataArr.forEach(item => {
             if(item.id === self.totalProducts) {
               $('.load-more').hide();
             }
          });
        }
      }, 400);
    });

    //DONE
    this.select.on('change', function () {
      self.currentPage = 1; //Need it to reset Current page
      self.categorySelected = $(this).val();
      $('.load-more').show();
      self.pageNavigate('', 0, 0, self.categorySelected);
    });

    //DONE
    $('.all-items-button').on('click', function () {
      let buttonValue = $(this).val();
      $(this).addClass('active-category');
      $('.category-buttons button').removeClass('active-category');
      self.categorySelected = '';
      self.pageNavigate(buttonValue, 0, 0, self.categorySelected);
    });

    //DONE
    $('body').on('click', '.category-buttons button', function () {
      $('.category-buttons button').removeClass('active-category');
      $('.all-items button').removeClass('active-category');
      $(this).addClass('active-category');
      self.categorySelected = $(this).attr('data-id');
      self.pageNavigate('', 0, 0, self.categorySelected);
    });

    //DONE
    $("body").on('click tap', `.pagination-number`, function (e) {
      e.preventDefault();
      let currentPageIndex = $(this).index();
      let nextItems = currentPageIndex * 4;
      self.pageNavigate('', currentPageIndex, nextItems, self.categorySelected);
    });

    $('body').on('click', '.pagination-button' , function () {
      let buttonValue = $(this).val();
      let getActiveIndex = $('.active').index();

      if (buttonValue === 'next') {
        let setNewActiveIndex = getActiveIndex + 1;
        let getNextValue = setNewActiveIndex * 4;
        self.pageNavigate(buttonValue, setNewActiveIndex, getNextValue, self.categorySelected);
      } else if (buttonValue === 'prev') {
        let setNewActiveIndex = getActiveIndex - 1;
        let getNextValue = (getActiveIndex - 1) * 4;
        self.pageNavigate(buttonValue, setNewActiveIndex, getNextValue, self.categorySelected);
      }else if (buttonValue === 'first') {
        self.pageNavigate(buttonValue, 0, 0, self.categorySelected);
      } else if (buttonValue === 'last'){
        let pageCount = Math.ceil(self.totalProducts / self.perPage);
        let setNewActiveIndex = pageCount - 1;
        let getNextValue = (pageCount - 1) * 4;
        self.pageNavigate(buttonValue, setNewActiveIndex, getNextValue, self.categorySelected);
      }
    });
  }
}
