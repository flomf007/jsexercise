// de facut un fetch sa iau datele
// cu 2 parametri skip/limit
// pt desenarea paginarii ma folosesc de parametru total
// de avut urmatoarele variabiel, currentPage, perPage, totalPages = (MathCeil(totalPages / perPage))
// total pages = for si desenez butoanele


class Pagination {

  constructor() {
    if (!$('.theme-pagination').length) {
      return
    }
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
    this.nextButton = $("#next-button");
    this.prevButton = $("#prev-button");
    this.currentPage = 1;
    this.perPage = 6;
    this.navigateButton = $('button');
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.onLoadFetchdataArr = [];
    this.pageContent = $('.container');
    this.nextButton = $("#next-button");
    this.prevButton = $("#prev-button");
    this.firstButton = $('.first-page');
    this.lasttButton = $('.last-page');
    this.setFirstPage = 1;
    this.paginationIndexStart = 0;
    this.onLoadLimit = 90;
    this.onLoadSkipElements = 0;
    this.elementDiv = $('.elementDiv');
    this.totalPosts = 0;
  }

  onLoadFetchdata(skipNumberOfElements) { //data fetched when page loads
    fetch(`https://dummyjson.com/posts?limit=${this.perPage}&skip=${skipNumberOfElements}`)
      .then((res) => res.json())
      .then((data) => {
          this.onLoadFetchdataArr = data.posts;
          this.totalPosts = data.total;
       });
  };

  appendData() {
    for (let i = 0; i < this.onLoadFetchdataArr.length; i++) {
      this.pageContent.append(`<div class="elementDiv" >
                <h3>
                <span>${this.onLoadFetchdataArr[i].id}. </span>
                  ${this.onLoadFetchdataArr[i].title}
                  </h3>
                <div class="container__post--content">   
                  <p>${this.onLoadFetchdataArr[i].body}</p>
                    <ul> 
                      <li>User id: ${this.onLoadFetchdataArr[i].userId}</li>
                      <li>Tags: ${this.onLoadFetchdataArr[i].tags.join(", ")}</li>
                      <li>Reactions: ${this.onLoadFetchdataArr[i].reactions}</li>
                    </ul>
                  </div>    
        </div>`)
    }
  }

  disableButton(button) {
    button.addClass("disabled");
    button.attr("disabled", true);
  };

  enableButton(button) {
    button.removeClass("disabled");
    button.attr("disabled", false);
  };

  /**
   * Listen for events
   */

  disableButtons(paginationNumber) {
    let self = this;
    let navigationNumberTabs = $('.pagination-number').length;

    if (paginationNumber === this.setFirstPage) {
      this.disableButton(self.prevButton);
      this.disableButton(self.firstButton);
    } else {
      this.enableButton(self.prevButton);
      this.enableButton(self.firstButton);
      this.disableButton(self.lasttButton);
    }

    if (navigationNumberTabs  === paginationNumber) {
      this.disableButton(self.nextButton);
      this.disableButton(self.lasttButton);
    } else {
      this.enableButton(self.nextButton);
      this.enableButton(self.lasttButton);
    }
  }

  drawPagination() {
    let self = this;
    let pageCount = Math.ceil(this.totalPosts / this.perPage);

    for (let i = 0; i < pageCount; i++) {
      $('#pagination-numbers').append(`<button class="pagination-number" page-index="${i + 1}" value="${i + 1}">${i + 1}</button>`);
    }

    $('.pagination-number').hide();
    $('.pagination-number').slice(0, 5).show();

    this.handleActivePageNumber(this.paginationIndexStart)
  }

  handleActivePageNumber(thisCurrentElIndex) {
    let self = this;
    let paginationElement = $('.pagination-number');
    paginationElement.removeClass('active');

    //The eq() method returns an element with a specific index number of the selected elements.
    // The index numbers start at 0, so the first element will have the index number 0 (not 1).

    $("body").find(paginationElement).eq(thisCurrentElIndex).addClass("active");

    self.handlePageNavigation(thisCurrentElIndex);

  }

  handlePageNavigation(thisCurrentElIndex) {
    if(thisCurrentElIndex >= 4) {
      $('.pagination-number').hide();
      $('.pagination-number').slice(thisCurrentElIndex - 2, thisCurrentElIndex + 3).show();
    } else if(thisCurrentElIndex > 0) {
      $('.pagination-number').hide();
      $('.pagination-number').slice(thisCurrentElIndex - 1, thisCurrentElIndex + 4).show();
    } else if (thisCurrentElIndex === 1){
      $('.pagination-number').hide();
      $('.pagination-number').slice(thisCurrentElIndex, thisCurrentElIndex + 5).show();
    }
  }

  pageNavigate(buttonValue, activePageIndex) {
    let self = this;
    if (buttonValue === 'prev') {
      let getPrevIndex = activePageIndex - 1;
      let elementsCalc = (activePageIndex - 1) * 6;
      this.setPagination(elementsCalc, getPrevIndex);
      this.disableButtons(activePageIndex);
    }
    else if (buttonValue === 'next') {
      let getNextIndex = activePageIndex + 1;
      let elementsCalc = (activePageIndex + 1) * 6;
      this.setPagination(elementsCalc, getNextIndex);

    } else if (buttonValue === 'first') {
      this.setPagination(0, 1);
      this.disableButtons(this.setFirstPage);

      setTimeout(function () {
        self.handleActivePageNumber(self.paginationIndexStart);
      }, 300);

    } else if (buttonValue === 'last'){
      let pagesElement = $('.pagination-number');
      let pagesLength = pagesElement.length;
      let elementsCalc = (pagesLength - 1) * 6;

      this.setPagination(elementsCalc, pagesLength - 1 );
      this.disableButtons(pagesLength);

      setTimeout(function () {
        //index is zero based . Our value is not
        self.handleActivePageNumber(pagesLength - 1);
      }, 300);

    }
  }

  setPagination(elementsCalc, getPrevIndex) {
    let self = this;

    this.onLoadFetchdata(elementsCalc);

    $('.elementDiv').remove();

    setTimeout(function () {
      self.appendData();
      self.handleActivePageNumber(getPrevIndex)
    }, 200);
  }

  calculatePosts(maximumElements, elementValueToCalc) {
    let self = this;

    let elementsCalc = (elementValueToCalc - 1) * 6;

    this.onLoadFetchdata(elementsCalc);

    $('.elementDiv').remove();

    setTimeout(function () {
      self.appendData();
    }, 200);

  }


  handleEvents() {
    let self = this;

    this.onLoadFetchdata(0);
    this.disableButtons(this.setFirstPage);

    setTimeout(function () {
      self.appendData();
      self.drawPagination();
    }, 300);

    $("body").on('click tap', `.pagination-number`, function (e) {
      e.preventDefault();

      let currentEl = $(this).index();
      let currentElValue = Number($(this).attr('value'));

      self.disableButtons(currentElValue);

      self.handleActivePageNumber(currentEl);

      self.calculatePosts(self.perPage, currentElValue);

    });

    self.navigateButton.on('click', function () {
      let getNavButtonVal = $(this).val();
      let getActiveIndex = $('.active').index();
      self.pageNavigate(getNavButtonVal, getActiveIndex);
    });

  }
}
