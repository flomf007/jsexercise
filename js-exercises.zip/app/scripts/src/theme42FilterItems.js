// de facut un fetch sa iau datele
// cu 2 parametri skip/limit
// pt desenarea paginarii ma folosesc de parametru total
// de avut urmatoarele variabiel, currentPage, perPage, totalPages = (MathCeil(totalPages / perPage))
// total pages = for si desenez butoanele


class NewPaginationFiltering {

  constructor() {
    if (!$('.filter-items').length) {
      return
    }
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
    this.elToLoad = 4;
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.onLoadFetchdataArr = [];
    this.categoryFetchDataArr = [];
    this.buttonCategory = [];
    this.itemsByCategory = [];
    this.pageContent = $('.listing-body ul');
    this.pageContentLi = $('.listing-body ul li');
    this.setFirstLoad = 1;
    this.loadMore = 4;
    this.limit = 100;
    this.categoryButtonsContainer = $('.category-buttons');
  }

  loaderDisplay(){
    let self = this;
    this.pageContent.addClass("show-loader");
    setTimeout(function () {
      self.pageContent.removeClass("show-loader");
    }, 500);
  }

  //DONE
  // appendData(categoryItem) {
  //   if(categoryItem === undefined) {
  //     this.onLoadFetchdataArr.forEach(item => {
  //       this.drawtemplate(item)
  //     })
  //   } else {
  //     this.itemsByCategory.forEach(item => {
  //       this.drawtemplate(item)
  //     });
  //   }
  // }

  //DONE
  // drawtemplate(categoryItem) {
  //   this.pageContent.append(`<li >
  //               <h3>
  //               <span>${categoryItem.id}. </span>
  //                 ${categoryItem.title}
  //                 </h3>
  //               <div class="container__post--content">
  //                  <h6>Get your at a discount price of ${categoryItem.discountPercentage} </h6>
  //                       <div class="image-area">
  //                            <img src="${categoryItem.thumbnail}" alt="">
  //                       </div>
  //                          <p> </p>
  //                       <ul>
  //                         <li>Brand: ${categoryItem.brand}</li>
  //                         <li>Category: ${categoryItem.category}</li>
  //                          <li>Description: ${categoryItem.description}</li>
  //                             <li>Price: ${categoryItem.price}</li>
  //                       </ul>
  //                 </div>
  //       </li>`)
  // }

  //DONE
  fetchCategoriesData(){
    fetch(`https://dummyjson.com/products/categories`)
      // fetch(`https://dummyjson.com/products`)
      .then((res) => res.json())
      .then((data) => {
        this.buttonCategory = data;
        // console.log(`fetched product categories`);
      });
  }

  //DONE
  fetchAllProductsData() {
    // fetch(`https://dummyjson.com`)
    fetch(`https://dummyjson.com/products`)
      .then((res) => res.json())
      .then((allData) => {
        this.categoryFetchDataArr = allData.products;
        // this.totalPosts = allData.total;
        this.totalPosts = allData.total;
        // console.log(`fetched all products`);
        return this.categoryFetchDataArr;
      });
  }

  //DONE
  drawFilterButtonsByCategory() {
    let self = this;
    self.buttonCategory.forEach(item => {
      self.categoryButtonsContainer.append(`
                                   <button class="filter-button" data-id="${item}"> ${item}</button>
                           `
      );
    });
  }

  // fetchItemsBycategory(itemsNumberToLoad, itemNumberOnFirstLoad, elementsCalcToLoad, category) {
  //   let self = this;
  //   // fetch(`https://dummyjson.com/products/category/${category}?limit=${this.loadMore}&skip=${skipNumberOfElements}`)
  //   fetch(`https://dummyjson.com/products/category/${category}`)
  //     .then((res) => res.json())
  //     .then((data) => {
  //       this.itemsByCategory = data.products;
  //
  //       console.log(this.itemsByCategory.length);
  //
  //       if( !$('.pagination-number').length && !$('.category-pagination-number').length){
  //         let pageCount = Math.ceil(this.itemsByCategory.length / this.elToLoad);
  //         for (let i = 0; i < pageCount; i++) {
  //           $('#pagination-numbers').append(`<button data-category='${category}' class="category-pagination-number" page-index="${i + 1}" value="${i + 1}">${i + 1}</button>`);
  //         }
  //       }
  //
  //       return this.itemsByCategory;
  //     });
  // }


  // calculateCategoryPosts(itemsNumberToLoad, itemNumberOnFirstLoad, totalNrOfElementsInItem, itemCategory){
  //   let self = this;
  //   this.setFirstLoad = itemNumberOnFirstLoad;
  //   this.loadMore = itemsNumberToLoad;
  //   let elementsCalcToLoad = (totalNrOfElementsInItem - 1) * 4;
  //
  //   this.loaderDisplay();
  //
  //   // this.fetchItemsBycategory(itemCategory, itemsNumberToLoad, elementsCalcToLoad);
  //   this.fetchItemsBycategory(itemsNumberToLoad, itemNumberOnFirstLoad, elementsCalcToLoad, itemCategory);
  //
  //   if(this.loadMore === this.totalPosts){
  //     $('.load-more-button').remove();
  //   }
  //
  //   setTimeout(function () {
  //     self.appendData(itemCategory);
  //   }, 200);
  // }

  fetchData(skipNumberOfElements) { //data fetched when page loads and on when clicked on Load more
    fetch(`https://dummyjson.com/products?limit=${this.elToLoad}&skip=${skipNumberOfElements}`)
      // fetch(`https://dummyjson.com/products`)
      .then((res) => res.json())
      .then((data) => {
        this.onLoadFetchdataArr = data.products;
        // console.log(`fetched data with skip`);
      });
  };

  loadMoreFunction(){

  }

  // detectAction(numberProducts, buttonCategory) {
  // detectAction(buttonCategory) {
  //   let self = this;
  //   //Reset DONE  -  Load more DONE
  //   if (buttonCategory === 'reset') {
  //     $('.listing-body ul li').remove();
  //     $('.pagination-number').remove();
  //     $('.category-pagination-number').remove();
  //     self.loaderDisplay();
  //     self.calculatePosts(self.elToLoad, 1 , 4);
  //     self.setFirstLoad = 1; //reset value for first load value back to 1
  //     self.loadMore = 4; //reset value for load more value back to 1
  //   } else if (buttonCategory === 'load-more') {
  //     self.calculatePosts(self.elToLoad, self.setFirstLoad + 1, self.loadMore + 4);
  //     self.loaderDisplay();
  //   } else if(buttonCategory === 'all-items') {
  //     $('.listing-body ul li').remove();
  //     self.calculatePosts(self.elToLoad, 1, 4);
  //     self.loaderDisplay();
  //     self.drawPagination();
  //   } else {
  //     $('.listing-body ul li').remove();
  //
  //     self.loaderDisplay();
  //     // console.log(buttonCategory);
  //     self.fetchItemsBycategory(buttonCategory, 5);
  //     setTimeout(function () {
  //       let totalNrOfElementsInItem = self.itemsByCategory.length;
  //
  //       self.calculateCategoryPosts(self.elToLoad, self.setFirstLoad,
  //         totalNrOfElementsInItem, buttonCategory);
  //
  //     }, 200);
  //
  //   }
  // }

  // calculatePosts(maximumElements, elementValueToCalc, addedNewElements) {
  //   let self = this;
  //   this.setFirstLoad = elementValueToCalc;
  //   this.loadMore = addedNewElements;
  //
  //   let elementsCalc = (elementValueToCalc - 1) * 4;
  //
  //   // de detectat daca primesc o categorie si fac fetch-ul in functie de astas
  //   // creez o variabila cu link-ul de fetch al tuturor produselor
  //   //la click pe categorie, actualizez variabila cu link-ul de categorie si ce alte valori mai am nevoie
  //   //ex variabila this.endpoint = https://dummyjson.com/products
  //   //ex variabila dupa click pe categorie this.endPoint =https://dummyjson.com/products/category/CATEGORIE
  //
  //   this.fetchData(elementsCalc);
  //
  //   this.loaderDisplay();
  //
  //   if(this.loadMore === this.totalPosts){
  //     $('.load-more-button').hide();
  //   }
  //
  //   setTimeout(function () {
  //     self.appendData();
  //   }, 200);
  //
  // }

  //DONE

  drawPagination() {
    if(!$('.pagination-number').length){
      let pageCount = Math.ceil(this.categoryFetchDataArr.length / this.elToLoad);
      for (let i = 0; i < pageCount; i++) {
        $('#pagination-numbers').append(`<button class="pagination-number" page-index="${i + 1}" value="${i + 1}">${i + 1}</button>`);
      }
    }
  }

  handleActivePageNumber(thisCurrentElIndex) {

    let paginationElement = $('.pagination-number');
    paginationElement.removeClass('active');

    //The eq() method returns an element with a specific index number of the selected elements.
    // The index numbers start at 0, so the first element will have the index number 0 (not 1).

    $("body").find(paginationElement).eq(thisCurrentElIndex).addClass("active");

    // self.handlePageNavigation(thisCurrentElIndex);

  }


  /**
   * Listen for events
   */


  handleEvents() {
    let self = this;

    this.fetchData(0);

    this.fetchCategoriesData();  //Categories data fetched
    this.fetchAllProductsData(); //All data fetched

    setTimeout(function () {
      self.appendData();
      // self.fetchCategoriesData();
      self.drawFilterButtonsByCategory();
    }, 300);

    //detect what action button was clicked
    $("body").on('click tap', `.buttons-area button`, function (e) {
      e.preventDefault();
      let getAction = $(this).attr('data-id');
      self.detectAction(getAction);
    });

    $("body").on('click tap', `.pagination-number`, function (e) {
      e.preventDefault();
      let currentEl = $(this).index();
      let currentElValue = Number($(this).attr('value'));
      $('.listing-body ul li').remove();
      self.handleActivePageNumber(currentEl);
      self.calculatePosts(self.elToLoad, currentElValue);
    });

    // $("body").on('click tap', `.category-pagination-number`, function (e) {
    //   e.preventDefault();
    //   let currentEl = $(this).index();
    //   let currentElValue = Number($(this).attr('value'));
    //   let currentCategory = $(this).attr('data-category');
    //   self.handleActivePageNumber(currentEl);
    //   self.fetchItemsBycategory(currentCategory, 3);
    //   console.log(self.itemsByCategory);
    //   self.calculateCategoryPosts(self.elToLoad, currentElValue, self.loadMore, currentCategory);
    // });

  }
}
