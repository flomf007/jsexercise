class LayoutHandler {

  constructor() {
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
  }

  /**
   * Listen for events
   */
  handleEvents() {
  }
}
