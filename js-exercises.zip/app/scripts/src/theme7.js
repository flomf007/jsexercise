class ThemeSeven {

  constructor() {
    if (!$('.theme-seven').length) {
      return
    }

    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
    this.tableTabs = $('.tabs-section div');
    this.content = $('.content-section .tab-content');
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {

  }

  displayTabItem(tabIndex){
    let self = this;
    this.content.removeClass('display');
    setTimeout(function () {
      $("body").find(self.content).eq(tabIndex).addClass('display');
    }, 150);

  }


  handleEvents() {
    let self = this;
    this.tableTabs.on('click', function () {
      $(this).toggleClass('display')
    })


  }
}
