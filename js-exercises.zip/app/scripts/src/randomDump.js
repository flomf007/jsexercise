

class LayoutHandler {

  constructor() {
    if(!$('.asdacxzczx').length) {
      return
    }
    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
  }

  /**
   * Handle DOM queries
   */

  //////////================== PAGINATION TEMA 17 ============= ////////////////
  createPagination(){


    // if(pageNumber > pageCount - 3 || pageNumber === pageCount) {
    //   $('.pagination-number').hide();
    //   $('.pagination-number').slice(pageNumber - 4, pageNumber ).show();
    // } else if (pageNumber === 1){
    //   $('.pagination-number').hide();
    //   $('.pagination-number').slice(pageNumber - 1, pageNumber + 5).show();
    // } else if (pageNumber >= 4) {
    //   $('.pagination-number').hide();
    //   $('.pagination-number').slice(pageNumber - 3, pageNumber + 2).show();
    // } else if(pageNumber > 1 && pageNumber < 4) {
    //   $('.pagination-number').hide();
    //   $('.pagination-number').slice(0, pageNumber + 5).show();
    // }


    // let paginationNumbers = document.getElementById("pagination-numbers");
    // let paginatedList = document.getElementById("paginated-list");
    // let listItems = paginatedList.querySelectorAll(".elementDiv");
    // let nextButton = document.getElementById("next-button");
    // let prevButton = document.getElementById("prev-button");
    //
    // let paginationLimit = 6;
    // let pageCount = Math.ceil(listItems.length / paginationLimit);
    // let currentPage = 1;

    // let getPaginationNumbers = () => {
    //   for (let i = 1; i <= pageCount; i++) {
    //     let drawPagination = $('.pagination-numbers').append(`<button class="pagination-number" page-index="${i}" aria-label="${i}">${i}</button>`);
    //     // appendPageNumber(i);
    //     return drawPagination
    //   }
    // };
    // let handlePageButtonsStatus = () => {
    //   if (currentPage === 1) {
    //     this.disableButton(prevButton);
    //   } else {
    //     this.enableButton(prevButton);
    //   }
    //
    //   if (pageCount === currentPage) {
    //
    //     this.disableButton(nextButton);
    //   } else {
    //     this.enableButton(nextButton);
    //     // enableButton(nextButton);
    //   }
    // };
    // let handleActivePageNumber = () => {
    //   document.querySelectorAll(".pagination-number").forEach((button) => {
    //     button.classList.remove("active");
    //     let pageIndex = Number(button.getAttribute("page-index"));
    //     if (pageIndex === currentPage) {
    //       button.classList.add("active");
    //     }
    //   });
    // };

    // let appendPageNumber = (index) => {
    //   let pageNumber = document.createElement("button");
    //   pageNumber.className = "pagination-number";
    //   pageNumber.innerHTML = index;
    //   pageNumber.setAttribute("page-index", index);
    //   pageNumber.setAttribute("aria-label", "Page " + index);
    //
    //   paginationNumbers.appendChild(pageNumber);
    // };

    // let setCurrentPage = (pageNum) => {
    //   currentPage = pageNum;
    //
    //   // handleActivePageNumber();
    //   // handlePageButtonsStatus();
    //
    //   let prevRange = (pageNum - 1) * paginationLimit;
    //   let currRange = pageNum * paginationLimit;
    //
    //   listItems.forEach((item, index) => {
    //     item.classList.add("hidden");
    //     if (index >= prevRange && index < currRange) {
    //       item.classList.remove("hidden");
    //     }
    //   });
    // };


    // getPaginationNumbers();
    // setCurrentPage(1);

    // prevButton.addEventListener("click", () => {
    //   setCurrentPage(currentPage - 1);
    //
    //   let abc = this.nextSixPosts + 6;
    //   let bcd = this.nextskip + 6;
    //   this.onLoadFetchdata(abc, bcd);
    //   // this.onLoadFetchdata(this.nextSixPosts - 6, this.nextskip - 6);
    //
    // });
    //
    // nextButton.addEventListener("click", () => {
    //   setCurrentPage(currentPage + 1);
    //   let abc = this.nextSixPosts + 6;
    //   let bcd = this.nextskip + 6;
    //   // console.log(abc);
    //   // console.log(bcd);
    //
    //   this.onLoadFetchdata(abc, bcd);
    // });

    // document.querySelectorAll(".pagination-number").forEach((button) => {
    //   let pageIndex = Number(button.getAttribute("page-index"));
    //
    //   if (pageIndex) {
    //     button.addEventListener("click", () => {
    //       setCurrentPage(pageIndex);
    //     });
    //   }
    // });

  }


  handleDOM() {
    // self.calculatePosts(self.elToLoad, self.setFirstLoad + 1, self.loadMore + 4, buttonCategory);

    // if(!$('.pagination-number').length){
    //   self.drawPagination(buttonCategory);
    // }

// self.fetchAlldata();
    // console.log(self.fetchAlldata());
    // setTimeout(function () {
    //   let i = 0;
    //
    //   self.categoryFetchDataArr.forEach(item => {
    //     // console.log(item.category);
    //     // console.log(buttonCategory);
    //     // console.log(buttonCategory);
    //     if(item.category === buttonCategory) {
    //       results.push(item);
    //       // console.log(results);
    //       // console.log(results.slice(0, 4));
    //       self.drawtemplate(item)
    //       // self.calculatePosts(self.elToLoad, 1,  4, results.slice(0, 4));
    //       // if (i < self.loadMore + 1) {
    //       //   self.drawtemplate(item)
    //       // }
    //     }
    //   });
    //
    // }, 300);


    // this.itemsByCategory.forEach((item, index) => {
    //   // $("body").find(paginationElement).eq(index).addClass("hidden");
    //   if (index >= calcPageElements && index < currRange) {
    //     //
    //     $("body").find(paginationElement).eq(index).removeClass("hidden");
    //     // this.pageContentLi[index].removeClass('hidden');
    //     // item.removeClass("hidden");
    //   }
    //
    //
    //
    //   if($("body").find(paginationElement).eq(index).length ){
    //     // console.log(`true`);
    //     // console.log($("body").find(paginationElement).eq(index).index());
    //     // console.log($(this).itemsByCategory);
    //     // $(this).addClass('hidden')
    //
    //
    //   } else {
    //     // $(this).removeClass('hidden')
    //     // console.log(`false`);
    //   }
    //
    //
    //
    //
    //
    // });


    // fetchItemsBycategoryLimit(category, numberOfItemsToLoad, itemsToSkip, elementsCalcToLoad ) {
    //   fetch(`https://dummyjson.com/products/category/${category}?limit=${numberOfItemsToLoad}&skip=${itemsToSkip}`)
    //     // fetch(`https://dummyjson.com/products/category/${category}`)
    //     .then((res) => res.json())
    //     .then((data) => {
    //       let self = this;
    //       this.itemsByCategoryLimit = data.products;
    //       console.log(this.itemsByCategoryLimit);
    //
    //     });
    //   return this.itemsByCategoryLimit;
    // }

    // $("body").on('click tap', `.category-pagination-number`, function (e) {
    //   e.preventDefault();
    //   self.pageContent.html('');
    //   let currentElIndex = $(this).index();
    //   let itemCategory = $(this).attr('data-category');
    //   self.fetchItemsByCategory(itemCategory, 4, currentElIndex);
    //   setTimeout(function () {
    //     self.appendData(itemCategory);
    //   }, 300);
    // });

    //=================  Filtring data JS     =======================================
  // <!--                       <p >Album nr: ${albumNr}</p>-->
    // <!-- <p>Albun id: ${albumIdds}</p>-->
    // <!--                      <img src="${self.cloneArr[i].url}" alt="${self.cloneArr[i].title}">-->
    //         self.albumListing.append(`
//                     <li class="album">
//                        <p >albumId: ${self.cloneArr[albumIdds].albumId}</p>
// <!--                       <p >albumId:${this}</p>-->
//                       <p>Albun nr: ${self.cloneArr[albumIdds].id}</p>
//
//                       <img src="${self.cloneArr[albumIdds].url}" alt="${self.cloneArr[albumIdds].title}">
//                     </li>`);
//     let a = [
//       {albumId : 1,
//         id: 1,
//         thumbnailUrl:"https://via.placeholder.com/150/92c952",
//         title:"accusamus beatae ad facilis cum similique qui sunt",
//         url:"https://via.placeholder.com/600/92c952"},
//       {albumId : 2,
//         id: 2,
//         thumbnailUrl:"https://via.placeholder.com/150/92c952",
//         title:"accusamus beatae ad facilis cum similique qui sunt",
//         url:"https://via.placeholder.com/600/92c952"},
//       {prop1:"bnmb",prop2:"yutu"},
//       {prop1:"zxvz",prop2:"qwrq"}];
//
//     let index = a.findIndex(x => x.albumId === 2);
//     console.log(index);

    // let reDrawList = function () {
    //   for (let i = 0; i < self.allListArr.length; i++) {
    //     self.albumListing.append(`
    //                 <li class="album">
    //                   <p>Albun nr: ${self.allListArr[i].id}</p>
    //                   <p >albumId: ${self.allListArr[i].albumId}</p>
    //                   <p>url: ${self.allListArr[i].url}</p>
    //                   <img src="${self.allListArr[i].url}" alt="${self.allListArr[i].title}">
    //                 </li>`);
    //   }
    // };
    // let reDrawList = function () {
    //   for (let i = 0; i < self.allListArr.length; i++) {
    //     self.albumListing.append(`
    //                 <li class="album">
    //                   <p>Albun nr: ${self.allListArr[i].id}</p>
    //                   <p >albumId: ${self.allListArr[i].albumId}</p>
    //                   <p>url: ${self.allListArr[i].url}</p>
    //                   <img src="${self.allListArr[i].url}" alt="${self.allListArr[i].title}">
    //                 </li>`);
    //   }
    // };

    // for (let j = 0; j < setAlbums.length; j++) {
    //   for (let k = 0; k < outputArray.length; k++) {
    //     if (setAlbums[j] === outputArray[k]) {
    //       start = true;
    //     }
    //   }
    //   count++;
    //   if (count === 1 && start === false) {
    //     outputArray.push(setAlbums[j]);
    //   }
    //   start = false;
    //   count = 0;
    // }

    // console.log(setAlbums);
    //
    // let countEl = 2;
    // let elCounter = 0;
    // for (let album of setAlbums) {
    //   if (album === countEl){
    //     elCounter++
    //   }
    // }
    // console.log(elCounter);


    // let drawList = function () { //Draw 3 items from each individual album
    //   let getAllAlbumsId = self.onLoadFetchdataArr.map(key => { //de redenumit setAlbumUniqid
    //     return key.albumId
    //   });
    //
    //   let getAlbumsUniqueId = [...new Set(getAllAlbumsId)]; //de redenumit un uniqIdArray sau ceva de genu
    //
    //   let getAlbum = self.onLoadFetchdataArr.map(key => { //de redenumit in item sau album
    //     return key
    //   });
    //
    //   console.log(getAllAlbumsId);
    //   // console.log(getAlbumsUniqueId);
    //   // console.log(outputArray);
    //   console.log(getAlbum);
    //
    //
    //
    //
    //   for (let i = 0; i < getAlbumsUniqueId.length; i++) {
    //     let index = getAlbum.findIndex(x => x.albumId === getAlbumsUniqueId[i]);
    //     self.albumListing.append(`
    //               <li class="album">
    //                   <p >Album nr: ${self.onLoadFetchdataArr[index].albumId}</p>
    //                   <p >Album id: ${self.onLoadFetchdataArr[index].id}</p>
    //                   <img src="${self.onLoadFetchdataArr[index].url}" alt="${self.onLoadFetchdataArr[index].title}">
    //               </li>`);
    //
    //     self.buttonsArea.append(`<div>
    //                                 <div class="button">
    //                                      <button class="abc" data-id="${getAlbumsUniqueId[i]}">Album ${getAlbumsUniqueId[i]}</button>
    //                                 </div>
    //                             </div>`
    //     );
    //   }
    // };
    //
    // let reDrawList = function () { //draw all albums with their albums
    //   for (let i = 0; i < self.onLoadFetchdataArr.length; i++) {
    //         self.albumListing.append(`
    //                     <li class="album">
    //                       <p >albumId: ${self.onLoadFetchdataArr[i].albumId}</p>
    //                       <p>Albun nr: ${self.onLoadFetchdataArr[i].id}</p>
    //                       <img src="${self.onLoadFetchdataArr[i].url}" alt="${self.onLoadFetchdataArr[i].title}">
    //                     </li>`);
    //       }
    // };
    //
    // let drawThreeAlbumItems = function() {
    //   let getAllAlbumsId = self.onLoadFetchdataArr.map(key => {
    //     return key.albumId
    //   });
    //
    //   let getAlbumsUniqueId = [...new Set(getAllAlbumsId)];
    //
    //   let getAlbum = self.onLoadFetchdataArr.map(key => {
    //     return key
    //   });
    //
    //   let results = [];
    //   console.log(getAlbumsUniqueId);
    //   for (let i = 1; i <= getAlbumsUniqueId.length; i++) {
    //     let items = getAlbum.filter((item) => {
    //       return item.albumId === i;
    //     }).slice(0, 3);
    //     items.forEach((item) => {
    //       results.push(item);
    //     });
    //
    //     console.log(results);
    //     console.log(results[i].id);
    //
    //     self.albumListing.append(`
    //                 <li class="album">
    //                     <p >Album nr: ${results[i].albumId}</p>
    //                     <p >Album id: ${results[i].id}</p>
    //                     <img src="${results[i].url}" alt="${results[i].title}">
    //                 </li>`);
    //   }
    //
    //   ///de facut foreach pe results, si facut templetizarea
    //
    // };



    // fetchAllListData() {
    //   fetch("https://jsonplaceholder.typicode.com/photos")
    //     .then((res) => res.json())
    //     .then((data) => {
    //       data.forEach((item) => {
    //         if (this.onLoadFetchdataArr.length < 30) {
    //           this.onLoadFetchdataArr.push(item);
    //         }
    //       });
    //     });
    // };


    // drawList() { //Draw 1 item from each individual album
    //   let getAllAlbumsId = this.onLoadFetchdataArr.map(key => { //de redenumit setAlbumUniqid
    //     return key.albumId
    //   });
    //
    //   let getAlbumsUniqueId = [...new Set(getAllAlbumsId)]; //de redenumit un uniqIdArray sau ceva de genu
    //
    //   let getAlbum = this.onLoadFetchdataArr.map(key => { //de redenumit in item sau album
    //     return key
    //   });
    //
    //   // console.log(getAllAlbumsId);
    //   // console.log(getAlbumsUniqueId);
    //   // console.log(outputArray);
    //   // console.log(getAlbum);
    //
    //
    //   for (let i = 0; i < getAlbumsUniqueId.length; i++) {
    //     let index = getAlbum.findIndex(x => x.albumId === getAlbumsUniqueId[i]);
    //     this.albumListing.append(`
    //               <li class="album">
    //                   <p >Album nr: ${this.onLoadFetchdataArr[index].albumId}</p>
    //                   <p >Album id: ${this.onLoadFetchdataArr[index].id}</p>
    //                   <img src="${this.onLoadFetchdataArr[index].url}" alt="${this.onLoadFetchdataArr[index].title}">
    //               </li>`);
    //
    //     this.buttonsArea.append(`<div>
    //                                 <div class="button">
    //                                      <button class="abc" data-id="${getAlbumsUniqueId[i]}">Album ${getAlbumsUniqueId[i]}</button>
    //                                 </div>
    //                             </div>`
    //     );
    //   }
    // };








  }

  /**
   * Listen for events
   */
  handleEvents() {
  }
}
