class FiltringData_tema_15 {

  constructor() {
    if (!$('.page-filtring-data').length) {
      return
    }

    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
  }


  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.albumListing = $('.display-filtring-items .listing-body ul');
    this.onLoadFetchdataArr = [];
    this.showAllAlbums = $('.show-all');
    this.buttonsArea = $('.buttons-area');
    this.button = $('.buttons-area .button button');
    this.albumsOnLoad = 3;
    this.albumsOnClick = 10;
  }

  onLoadFetchdata() { //data fetched when page loads
    fetch("https://jsonplaceholder.typicode.com/photos")
      .then((res) => res.json())
      .then((data) => {
        this.onLoadFetchdataArr = data.slice(0, 500);
      });
  };

   drawButtons() {
    let getAllAlbumsId = this.onLoadFetchdataArr.map(key => {
      return key.albumId
    });
    let getAlbumsUniqueId = [...new Set(getAllAlbumsId)];

    for (let i = 0; i < getAlbumsUniqueId.length; i++) {
      this.buttonsArea.append(`<div>
                  <div class="button">
                       <button class="filter-button" data-id="${getAlbumsUniqueId[i]}">Album ${getAlbumsUniqueId[i]}</button>
                  </div>
              </div>`
      );
    }
  }

  drawtemplate(indexVal) {
    let albumTemplate = `<li class="album">
                      <p >Album nr: ${indexVal.albumId}</p>
                      <p >Album id: ${indexVal.id}</p>
                      <img src="${indexVal.url}" alt="${indexVal.title}">
                    </li>`;
    return albumTemplate;
  }

  drawAlbums(numberAlbumItems, buttonId) {
    let getAllAlbumsId = this.onLoadFetchdataArr.map(key => {
      return key.albumId;
    });

    let results = [];

    for(let i = 1; i <= getAllAlbumsId.length; i++) {
      let items = this.onLoadFetchdataArr.filter((item) => {
        return item.albumId === i;
      }).slice(0, numberAlbumItems);
      items.forEach((item) => {
        results.push(item);
      });
    }

    if(buttonId === undefined) {
      for (let i = 0; i < results.length; i++) {
        this.albumListing.append(this.drawtemplate(results[i]));
      }
    } else {
      for (let i = 0; i < results.length; i++) {
        if(results[i].albumId === buttonId) {
          this.albumListing.append(this.drawtemplate(results[i]));
        }
      }
    }
  }

  /**
   * Listen for events
   */
  handleEvents() {
    let self = this;

    this.onLoadFetchdata();

    setTimeout(function () {
      self.drawButtons();
      self.drawAlbums(self.albumsOnLoad)
    }, 300);

    $("body").on('click tap', `.filter-button`, function (dataButton) {
      self.albumListing.empty();
      dataButton = Number($(this).attr('data-id'));
      self.drawAlbums(self.albumsOnClick, dataButton)
    });

    this.showAllAlbums.on('click', function () {
      self.albumListing.empty();
      setTimeout(function () {
        self.drawAlbums(self.albumsOnLoad);
      }, 200)
    });

  }
}
