class MyScript {

  constructor() {
    if (!$('.page-tic-tak-toe').length) {
      return
    }
    this.handleEvents();
    this.init();
    this.handleDOM();

  }


  /**
   * Declare global variables
   */
  init() {
     }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.tikTakBox = $('.tikTakBox');
    this.playerOne = $('.player-one');
    this.playerTwo = $('.player-two');
    this.box = $('.container');
    this.playerOneName = 'X';
    this.playerTwoName = '0';
    this.nextPlayer = $('.player-playing');
  }

  drawBoxes(index){
    let drawTemplate =  $('.tik-tak ul').append(`<li class="tikTakBox" id="${index}"></li>`);
    return drawTemplate;
  }

  switchPlayer() {
    this.playerTwo.toggleClass('active');
    this.playerOne.toggleClass('active');
  }

  updateGameTextDisplay(letter, elClicked){
    let playerPlaying = $('.player-playing p');
    playerPlaying.remove();

    elClicked.addClass('disabled').text(letter);

    letter === this.playerOneName ?
      this.nextPlayer.append(`<p>Player two(<strong>${this.playerTwoName}</strong>) turn</p>`) && this.switchPlayer() :
      this.nextPlayer.append(`<p>Player one(<strong>${this.playerOneName}</strong>) turn</p>`) && this.switchPlayer();

    this.checkCombinations(elClicked);

  }

  checkCombinations(playerTurn){
    let self = this;
    let disabledEl = $('.disabled');
    let thisBoxOne = $('#0').text();
    let thisBoxTwo = $('#1').text();
    let thisBoxThree = $('#2').text();
    let thisBoxFour = $('#3').text();
    let thisBoxFive = $('#4').text();
    let thisBoxSix = $('#5').text();
    let thisBoxSeven = $('#6').text();
    let thisBoxEight = $('#7').text();
    let thisBoxNine = $('#8').text();

    if (disabledEl.length === 9) {
      self.displayMessage('draw')
    } else if(thisBoxOne === thisBoxTwo && thisBoxTwo === thisBoxThree && thisBoxThree === playerTurn.text()){
      self.displayMessage(playerTurn);
    } else if (thisBoxFour === thisBoxFive && thisBoxFive === thisBoxSix && thisBoxSix === playerTurn.text()) {
      self.displayMessage(playerTurn);
    } else if(thisBoxSeven === thisBoxEight && thisBoxEight === thisBoxNine && thisBoxNine === playerTurn.text()){
      self.displayMessage(playerTurn);
    } else if(thisBoxOne === thisBoxFive && thisBoxFive === thisBoxNine && thisBoxNine === playerTurn.text()) {
      self.displayMessage(playerTurn);
    } else if(thisBoxSeven === thisBoxFive && thisBoxFive === thisBoxThree && thisBoxThree === playerTurn.text()) {
      self.displayMessage(playerTurn);
    } else if(thisBoxOne === thisBoxFour && thisBoxFour === thisBoxSeven && thisBoxSeven === playerTurn.text()) {
      self.displayMessage(playerTurn);
    } else if (thisBoxTwo === thisBoxFive && thisBoxFive === thisBoxEight && thisBoxEight === playerTurn.text()) {
      self.displayMessage(playerTurn);
    } else if (thisBoxThree === thisBoxSix && thisBoxSix === thisBoxNine && thisBoxNine === playerTurn.text()) {
      self.displayMessage(playerTurn);
    }
  }

  displayMessage(playerTurn){
    let displayPlayersTurn = $('.player-playing p');
    let gameBoxes = this.tikTakBox;
    displayPlayersTurn.remove();

    if(playerTurn === 'reset') {
        gameBoxes.removeClass('disabled');
        gameBoxes.text('');
        this.switchPlayer();
        displayPlayersTurn.remove();
        this.nextPlayer.append(`<p>Player one(<strong>${this.playerOneName}</strong>) turn</p>`);
    } else if(playerTurn === 'draw') {
        this.nextPlayer.append(`<p>It's a draw</p>`);
        gameBoxes.addClass('disabled');
    } else {
        this.nextPlayer.append(`<p>Player ${playerTurn.text()} won</p>`);
        gameBoxes.addClass('disabled');
    }

  }

  /**
   * Listen for events
   */
  handleEvents() {
    let self = this;
    let maxNrBoxes = 9;

    setTimeout(function () {
      $('.overflow-text').fadeOut();
    }, 500);

    //draw boxes
    for (let i = 0; i < maxNrBoxes ; i++) {
      this.drawBoxes(i);
    }

    $('.tikTakBox').on('click', function () {
      let currentEl = $(this);

      if (self.playerOne.hasClass('active')){
        self.updateGameTextDisplay(self.playerOneName, currentEl);
      } else {
        self.updateGameTextDisplay(self.playerTwoName, currentEl);
      }
    });


    $('.reset').on('click', function () {
      self.displayMessage('reset');
    })

  }
}



