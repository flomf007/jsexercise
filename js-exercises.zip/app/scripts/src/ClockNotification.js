class ClockNotification {

  constructor() {
    if (!$('.page-clock').length) {
      return
    }

    this.init();
    this.handleDOM();
    this.handleEvents();
  }

  /**
   * Declare global variables
   */
  init() {
    this.dataArr = [];
  }

  /**
   * Handle DOM queries
   */
  handleDOM() {
    this.form = $('#datesForm');
    this.activityTemplate = $(".display-dates__values-container ul");
    this.popupModal = $('.modal');
    this.closeModal = $('.modal-close');
    this.messageSucces = $('.message-display');
    this.actionMessageTitle = $('.action-message-title p');
    this.addDateMessage = 'Add new date';
    this.editDateMessage = 'Edit date';
    this.itemId = '';
  }

  getTheTime() {
    let self = this;
    let getDataFromLocalStorage = JSON.parse(localStorage.getItem('savedData'));
    let hourArrow = document.querySelector('.small-arrow');
    let minuteArrow = document.querySelector('.medium-arrow');
    let secondsArrow = document.querySelector('.big-arrow');
    let currentDate = new Date();
    let hr = currentDate.getHours();
    let min = currentDate.getMinutes();
    let hourArrowRotation = 30 * hr + min / 2; //converting current time
    let minArrowRotation = 6 * min;
    let secondsArrowRotation = (currentDate.getSeconds() / 60) * 360;

    hourArrow.style.transform = `rotate(${hourArrowRotation}deg)`;
    minuteArrow.style.transform = `rotate(${minArrowRotation}deg)`;
    secondsArrow.style.transform = `rotate(${secondsArrowRotation}deg)`;

    if(getDataFromLocalStorage !== null){
      self.dataArr = getDataFromLocalStorage;
      getDataFromLocalStorage.map(item => {
        let currentTime = Date.parse(new Date()) / 1000;
        let itemScheduled = Math.round(new Date(item.date).getTime()/1000);

        if (currentTime === itemScheduled) {
          self.itemId = item.id;
          if (!this.popupModal.hasClass('show')) {
            this.popupModal.addClass('show');
            $('.modal-title').text(`${item.title} - ${item.date}`);
            $('.modal-body p').text(`${item.description}`);
          }
        }
      });
      localStorage.setItem('savedData', JSON.stringify(self.dataArr));
    }
  }

  setLocalStorage(title, description, date, id) {
    let self = this;
    let getDataFromLocalStorage = JSON.parse(localStorage.getItem('savedData'));
    let clockDataInfo = {
      'title': `${title}`,
      'description': `${description}`,
      'date': `${date}`,
      'id': `${id}`
    };

    if(id !== self.itemId) { //If item.Id has a value, it means that the id we received has been edited
      self.dataArr.push(clockDataInfo); //push new item in array that is passed into our local storage
      this.activityTemplate.append(`<li id="${id}">
                                                <div class="date value"><p>${date}</p></div>
                                  
                                                <div class="title value"><p>${title}</p></div>
                                                <div class="btns-area">
                                                   <button class="edit"></button>
                                                   <button class="delete"></button>
                                                </div>
                                              </li>`);
    } else {

      let newDate = Math.round(new Date(date).getTime() / 1000); //transform our item date into timestamp
      let findItemInLocalStorage = getDataFromLocalStorage.findIndex(
        (obj) => obj.id === id,
      );
      self.dataArr[findItemInLocalStorage].title = title;
      self.dataArr[findItemInLocalStorage].description = description;
      self.dataArr[findItemInLocalStorage].date = date;
      self.dataArr[findItemInLocalStorage].id = newDate.toString();
      this.activityTemplate.html('');
      setTimeout(function () {
        self.getDataFromLocalStorage();
      }, 300);
      $('.edited .title p').html(title);
      $('.edited .description p').html(description);
      $('.edited .date p').html(`${date.slice(11, 16)}`);
    }
    localStorage.setItem('savedData', JSON.stringify(self.dataArr));
  }

  getDataFromLocalStorage(){
    let self = this;
    let getDataFromLocalStorageKey = JSON.parse(localStorage.getItem('savedData'));

    if(getDataFromLocalStorageKey !== null) {
      self.dataArr = getDataFromLocalStorageKey;
        getDataFromLocalStorageKey.map(item => {
            this.activityTemplate.append(`<li id="${item.id}">
                                                <div class="date value"><p>${item.date}</p></div>
                                                <div class="title value"><p>${item.title}</p></div>
                                                <div class="btns-area">
                                                   <button class="edit"></button>
                                                   <button class="delete"></button>
                                                </div>

                                              </li>`)
        });
    }
  }

  getItemFromLocalStorage(item, action){
    let self = this;
    let getDataFromLocalStorage = JSON.parse(localStorage.getItem('savedData'));
    self.dataArr = getDataFromLocalStorage;
    let itemIndex = getDataFromLocalStorage.findIndex(
      (obj) => obj.id === item,
    );
    if (itemIndex > -1) {
      if(action === 'delete' || action === 'remove') {
        getDataFromLocalStorage.splice(itemIndex, 1);
      } else if (action === 'edit'){
        setTimeout(function(){
          $('#title').val(getDataFromLocalStorage[itemIndex].title);
          $('#description').val(getDataFromLocalStorage[itemIndex].description);
          $('#date').val(getDataFromLocalStorage[itemIndex].date);
        }, 200);
      }
    }
    self.dataArr = getDataFromLocalStorage;
    localStorage.setItem('savedData', JSON.stringify(self.dataArr));
  }

  addActivities(){
    $('.clock-page').removeClass('display-activities');
    $('.clock-page').toggleClass('display-add-dates');
  }
    /**
   * Listen for events
   */
  handleEvents() {
    let self = this;
    this.getTheTime();
    this.getDataFromLocalStorage();

    setInterval(function () {
      self.getTheTime();
    }, 1000);

    $.validator.addMethod("onlyLetters", function (value, element) { //with spaces in between
      return this.optional(element) || /^[a-zA-Z\s]+$/g.test(value);
    }, "");

      this.form.validate({
        rules: {
          title:{
            required: true,
          },
          description: {
            required: true,
          },
          date: {
            required: true,
          },
          messages: {
            title:{
              required: 'Acest camp este obligatoriu',
            },
            description: {
              required: 'Acest camp este obligatoriu',
            },
            date: {
              required: 'Acest camp este obligatoriu',
            },
          }
        },
        submitHandler: function (form, event) {
          event.preventDefault();
          let getTitle = $('#title').val();
          let getDescription = $('#description').val();
          let getDate = $('#date').val();

          setTimeout(function () {
            if(self.itemId !== '') {
              self.setLocalStorage(getTitle, getDescription, getDate, self.itemId);
            } else if (getTitle !== '' && getDescription !== '' && getDate !== '') {
              let id =  new Date(getDate).getTime();
              self.setLocalStorage(getTitle, getDescription, getDate, id);
            }
            $('#title').val('');
            $('#description').val('');
            $('#date').val('');
            self.itemId = '';
          }, 200);
          self.messageSucces.html('<p>Values have been added</p>');

          }
      });

    $('.display-activities').on('click', function () {
        $('.clock-page').toggleClass('display-activities');
        $('.clock-page').removeClass('display-add-dates');
        self.itemId = '';
    });

    $('.add-activities').on('click', function () {
      self.addActivities();
      self.actionMessageTitle.text('');
      self.itemId = '';
      self.messageSucces.html('');
      self.actionMessageTitle.text(self.addDateMessage);
    });

    $('#datetimepicker1').datetimepicker().show();

    $('body').on('click tap', '.delete', function () {
      self.itemId = $(this).closest('li').attr('id');
      $('li#' + self.itemId).remove();
      self.getItemFromLocalStorage(self.itemId, 'delete')
    });

    $('body').on('click tap', '.edit', function () {
      self.itemId = $(this).closest('li').attr('id');
      self.addActivities();
      self.getItemFromLocalStorage(self.itemId, 'edit');
      self.actionMessageTitle.text('');
      self.actionMessageTitle.text(self.editDateMessage);
    });

    this.closeModal.on('click', function () {
      self.popupModal.removeClass('show');
      $('li#' + self.itemId).remove();
      self.getItemFromLocalStorage(self.itemId,'remove');
      self.itemId = '';
    });

  }
}
